
class ErreurDeplacement(Exception):
    pass

class AucunePieceAPosition(Exception):
    pass

class MauvaiseCouleurPiece(Exception):
    pass
